#until modifier(Opposite of while modifier and only get executed when the condition is false (but will be executed at least once))
$i = 0
$num = 5
begin
   puts("Inside the loop i = #$i" )
   $i +=1;
end until $i > $num