#until (It is opposite of while and only get executed when the conditional is false)
$i = 0
$num = 5

until $i > $num  do
   puts("Inside the loop i = #$i" )
   $i +=1;
end