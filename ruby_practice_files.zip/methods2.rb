#Ruby Methods when variable no. of parameters are passed

def method2(*para)
	puts "The no. of parameters are: #{para.length}"
	for i in 0...para.length
		puts "The parameters are: #{para[i]}"
	end
end
method2 "Annie", "One year"
method2 "Jammie", 1, "picnic"
method2 "Mac", "36", "M", "MCA"