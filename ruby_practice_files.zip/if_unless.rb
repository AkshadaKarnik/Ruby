
#Ruby if-else, if modifier, unless, unless modifier

#if-else
num = 1	#a local variable
if num > 2
   puts "x is greater than 2"
elsif num <= 2 and num!=0
   puts "number is 1"
else
   puts "I can't guess the number"
end

#***********************************************************************************************************
#if modifier
$debug = false	
#Note: even on giving 0 to this global variable, it is treated as true and only on using false or blank it'll be treated as false and the statement will not be printed
print "debug\n" if $debug
#***********************************************************************************************************

#unless
x = 1 
unless x>=2
   puts "x is less than 2"
 else
   puts "x is greater than 2"
end
#***********************************************************************************************************

#unless modifier
$var =  1
print "1 -- Value is set\n" if $var
print "2 -- Value is set\n" unless $var

$var = false
print "3 -- Value is set\n" unless $var
#***********************************************************************************************************

=begin
So, these are just opposite of if and if modifier respectively MEANS- Here if the conditional is false then only 
instructions get executed =end
=end