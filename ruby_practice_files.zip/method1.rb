#Ruby Methods when some parameters are passed

def method1(a1="Ruby", a2="Python")
	puts "The programming language is: #{a1}"
	puts "The programming language is: #{a2}"
end
method1 "C", "C++"
method1