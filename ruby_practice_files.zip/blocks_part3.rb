#BEGIN and END blocks

BEGIN{
	puts "This is the begin statement of block"
}
END{
	puts "This is the end statement of block"
}
puts"This is the main statement block"