
#Ruby CLASS METHODS & INSTANCE METHODS

require 'byebug'

class Fruits
	$a=10;
	self	#Caller to Fruits
	def xyz	#This is an INSTANCE METHOD
		self	#here self is a caller to the object obj1 of Fruits class
		Fruits.pqr
	end
	def abc	#This is also an INSTANCE METHOD
		byebug
		self	#here self is the caller to the object obj2
	end
	
	#Note: If no object created for any instance method then self will be a caller of that class (eg. here Fruits)

	def self.pqr	#here pqr is the method3 of Fruits class (This is a CLASS METHOD)
		byebug
		"Hi I'm method3"	#Caller to Fruits class
	end
end
Fruits.new.xyz	#obj 1 created and accessing method1 xyz
Fruits.new.abc	#obj2 created and accessing method2 abc	def abc	#This is also an INSTANCE METHOD
