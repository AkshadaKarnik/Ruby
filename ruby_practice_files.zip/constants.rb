#Ruby Constants

class A
	def cust
		VAR1 = 10
		VAR2 = 20
	end
	def show_Var
		puts "The value of var1 is: #VAR1"
		puts "The value of var2 is: #VAR2"
	end
end
obj1 = A.new
obj2 = A.new

obj1.show_Var
obj2.show_Var