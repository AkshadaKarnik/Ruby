#for loop (Executes code once for each element in expression)
for i in 0..5
   puts "Value of local variable is #{i}"
end