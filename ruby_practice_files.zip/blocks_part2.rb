#Ruby Blocks part 2

def of_block
	puts "This is the statement 1 in of_block method"
	yield 6
	puts "This is the statement 2 in of_block method"
	yield 4
end
of_block{|i| puts"Hi, I'm a block! #{i}"}