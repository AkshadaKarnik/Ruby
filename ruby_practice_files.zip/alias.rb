#Ruby alias statement in methods

def original
	puts "Hello! I'm Original"
end
alias fake original
fake


=begin
#Ruby undef statement in methods
undef original
=end