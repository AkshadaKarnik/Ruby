#Ruby Global variable

$global_var = 20;
class Class1
	def print_global
		puts "Global variable in Class1 is #$global_var"
	end
end
class Class2
	def print_global
		puts "Global variable in Class2 is #$global_var"
	end
end

class1_obj = Class1.new
class1_obj.print_global
class2_obj = Class2.new
class2_obj.print_global