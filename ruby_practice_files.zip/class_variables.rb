#Ruby Class variable

class Customer
	@@Total_customers = 0
	def initialize(id, name, address)
		@cust_id = id
		@cust_name = name
		@cust_addr = address
	end
	def show_details()
		puts "Customer id is: #@cust_id"
		puts "Customer name is: #@cust_name"
		puts "customer address is: #@cust_addr"
	end
	def total()
		@@Total_customers += 1
		puts "Total customers : #@@Total_customers"
	end
end

	c1 = Customer.new("A1", "Ram", "Ram Nagar")
	c2 = Customer.new("B22", "Shyam", "Silicon Valley")
	c3 = Customer.new("A4", "John", "Gen Square")

	#c1.show_details()
	c1.total()
	#c2.show_details()
	c2.total()
	#c3.show_details()
	c3.total()