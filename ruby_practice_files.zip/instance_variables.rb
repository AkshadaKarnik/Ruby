#Ruby Instance variable

class Student
	def initialize roll, name, city
		@stud_roll = roll
		@stud_name = name
		@stud_city = city
	end
	def show_details
		puts "Roll No. is #@stud_roll"
		puts "Name is #@stud_name"
		puts "City is #@stud_city"
	end
end

stud_obj1 = Student.new 1, "John", "Indore" 
stud_obj2 = Student.new 2, "Annie", "Bengaluru" 

stud_obj1.show_details
stud_obj2.show_details
