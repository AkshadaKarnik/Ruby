#Ruby Blocks part 1

def of_block
		puts "This is the statement 1 in of_block method"
		yield
		puts"This is the statement 2 in of_block method"
		yield
	end
of_block{puts"Hi, I'm a block!"}